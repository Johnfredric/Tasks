const express = require('express');
const app = express();
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
require('dotenv/config');

//Files
const router = require('./router');

app.use(cookieParser());
app.use(express.json());


app.use('/api',router);




//DB connection
mongoose.connect(process.env.MONGO_URI,(err)=>{
    if(err){
        throw err;
    }
    console.log("DB connected successfully");
});



//PORT
app.listen(8080,()=>{
    console.log('server started on port 8080...');
});