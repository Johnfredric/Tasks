const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const users = require('./model/userschema');

//Local module
const {hashGenerate} = require('./Auth/hashing');
const {hashValidator} = require('./Auth/hashing');
const {tokenGenerator} = require('./Auth/jwt');
const {tokenValidator} = require('./Auth/jwt');


//Post
router.post('/signup',async(req,res)=>{
    const hashPassword = await hashGenerate(req.body.password);
    try {
        const postUser = await new users({
            name:req.body.name,
            email:req.body.email,
            password:hashPassword
        });
        const saveUser = await postUser.save();
        res.json(saveUser);
    } catch (error) {
        res.json(error);
    }
});

//Signin After Password Hashing
router.post('/signin',async (req,res)=>{
    try {
        const existingUser = await users.findOne({email:req.body.email});
        if(!existingUser){
            res.json('Email is Invalid');
        }else{
            const checkUser = await hashValidator(req.body.password,existingUser.password);
            if(!checkUser){
                res.json('Password is Invalid');
            }else{
                const token = await tokenGenerator(existingUser.email);
                res.cookie('jwtToken',token);
                res.json(token);
            }
            
        }
        
    } catch (error) {
       res.json(error); 
    }
});


//GetAll User
router.get('/users',async(req,res)=>{
    try {
        const getAll = await users.find();
        res.json(getAll);
        
    } catch (error) {
        res.json(error);
    }
});

//Get User by ID
router.get('/users/:id',async(req,res)=>{
    try {
        const getByid= await users.findById(req.params.id);
        res.json(getByid);
    } catch (error) {
        res.json(error)
    }
});

//Update User by ID 
router.patch('/user/update/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const updatedData = req.body;
        const result = await users.findByIdAndUpdate(id, updatedData);

        res.json(result);
    }
    catch (error) {
        res.json(error)
    }
});

//Delete User by ID
router.delete('/delete/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const data = await users.findByIdAndDelete(id)
        res.json(`Document ${data.name} has been deleted..`)
    }
    catch (error) {
        res.json(error);
    }
});


module.exports= router;