const path = require('path');
const fs = require('fs');


//WriteFile and ReadFile
fs.writeFile(path.join(`${__dirname}/fswrite.js`),'welcome to writeFile page...',(err)=>{
    if(err){
        throw err
    }
    fs.readFile(path.join(`${__dirname}/fswrite.js`),'utf8',(err,data)=>{
        console.log(data);
    });
    console.log('File created and write the text successfully....');
});