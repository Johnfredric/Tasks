const express = require('express');
const app = express();
const mongoose = require('mongoose')



//Callback Function and simple webApp
app.get('/',(req,res)=>{
    res.send("welcome to the Application...")
})


app.listen(3000,()=>{
    console.log('server started on port 3000...');
});




//Promise
const callMe =new Promise ((resolve,reject)=>{
    if(true){
        resolve('resolve...');
    }else{
        reject('reject');
    }
});

callMe
.then(result=>{
    console.log(result)
})
.catch(err=>{
    console.log(err);
})





//Async-await
app.get('/user/:id',async(req,res)=>{
    try {
        const getById = await users.findById(req.params.id);
        res.json(getById);

    } catch (error) {
        res.json(error);
    }
});
