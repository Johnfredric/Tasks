const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const users= require('./userSchema');


//Post user
router.post('/post',async (req,res)=>{
    try {
        const postUser = await new users({
            username:req.body.username,
            email:req.body.email,
            password:req.body.password
        });
        const saveUser= await postUser.save(); 
        res.json(saveUser); 
    } catch (error) {
        res.json(error)
    }
});

//Get users
router.get('/users',(req,res)=>{
    users.find((err,data)=>{
        if(err){
            throw err;
            }

        res.json(data);
        });    
});

//Get user by ID
router.get('/user/:id',async(req,res)=>{
    try {
        const getById = await users.findById(req.params.id);
        res.json(getById);

    } catch (error) {
        res.json(error);
    }
});

//Put user by ID
router.put('/users/:id',(req,res)=>{
    users.updateOne({_id:req.params.id},{username:req.body.username,email:req.body.email},(err)=>{
        if(err){
            throw err;
        }else{
            res.json("User updated successfully");
        }
    });
});

//patch user by ID
router.patch('/user/:id',(req,res)=>{
    users.updateOne(
        {id:req.params.id},
        {$set:req.body},
        (err)=>{
            if(err){
                res.json(err);
            }
            res.json("User updated successfully");
        
        }
    );
});



//Delete user by ID
router.delete('/user/:id',(req,res)=>{
    users.findByIdAndRemove({_id:req.params.id},(err)=>{
        if(err){
            throw err;
        }else{
            res.json('User deleted successfully');
        }
    });
});



module.exports= router;