const express = require('express');
const app = express();
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
require('dotenv/config');
const morgan = require('morgan');
//Files
const router = require('./router');



//Middleware
app.use(express.json());
app.use(morgan('dev'));


app.use('/api',router);


//DB Connection
mongoose.connect(process.env.DB_URI,(err)=>{
    if(err){
        throw err;
    }else{
        console.log('DB connected successfully...')
    }
});

//PORT
PORT = process.env.PORT || 3000;
app.listen(PORT,()=>{
    console.log(`Server started on port ${PORT}....`);
});